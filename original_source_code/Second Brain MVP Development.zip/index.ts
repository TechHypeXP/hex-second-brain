// Located at: supabase/functions/embed-and-store/index.ts

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { Pinecone } from 'https://esm.sh/@pinecone-database/pinecone@2.2.0'
import { OpenAI } from "https://esm.sh/openai@4.40.2";

// CORS headers to allow requests from your web app
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

console.log("Edge function 'embed-and-store' is ready.");

serve(async (req) => {
  // This is needed for the browser to make a "preflight" request to see if the server allows the actual request
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // 1. Initialize API clients using securely stored environment variables
    // The admin client has elevated privileges to read/write data
    const supabaseAdminClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    // Initialize Pinecone client
    const pinecone = new Pinecone({
      apiKey: Deno.env.get('PINECONE_API_KEY') ?? '',
    });
    
    // Initialize OpenAI client for creating embeddings
    const openai = new OpenAI({
      apiKey: Deno.env.get("OPENAI_API_KEY"),
    });

    // 2. Get the resource ID from the JSON body of the request
    const { resourceId } = await req.json();
    if (!resourceId) {
      throw new Error("A 'resourceId' is required in the request body.");
    }

    // 3. Fetch the resource content from your database using the ID
    const { data: resource, error: resourceError } = await supabaseAdminClient
      .from('resources')
      .select('content, user_id, space_id')
      .eq('id', resourceId)
      .single(); // .single() expects only one result

    if (resourceError) throw resourceError;
    if (!resource || !resource.content) {
      return new Response(JSON.stringify({ message: 'Resource not found or has no content.' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 404,
      });
    }

    // 4. Create a vector embedding from the resource's content using OpenAI
    const embeddingResponse = await openai.embeddings.create({
      model: "text-embedding-ada-002", // A powerful and common model for this task
      input: resource.content.replace(/\n/g, ' '), // Clean up newlines for better embedding results
    });
    
    const vector = embeddingResponse.data[0].embedding;

    // 5. Upsert (insert or update) the vector into your Pinecone index
    // We use a namespace to isolate data, e.g., per-user or per-space
    const namespace = resource.space_id || resource.user_id;
    if (!namespace) {
         throw new Error("Cannot determine a namespace for the Pinecone vector.");
    }
    
    const indexName = Deno.env.get('PINECONE_INDEX_NAME') ?? '';
    const index = pinecone.index(indexName);
    
    await index.namespace(namespace).upsert([
      {
        id: resourceId,
        values: vector,
        metadata: {
          // You can add any metadata you want to search/filter on later
          resourceId: resourceId,
          userId: resource.user_id
        },
      },
    ]);
    
    // 6. Update your own database to mark the resource as processed
    await supabaseAdminClient
        .from('resources')
        .update({ processing_status: 'completed', processed_at: new Date().toISOString() })
        .eq('id', resourceId);


    // 7. Return a success response
    return new Response(JSON.stringify({ success: true, message: `Resource ${resourceId} was embedded and stored successfully.` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error) {
    // Return an error response if anything goes wrong
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500, // Use 500 for server-side errors
    });
  }
});

